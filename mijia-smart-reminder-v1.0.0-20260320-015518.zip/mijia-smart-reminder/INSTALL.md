# 安装说明

## 🚀 快速安装

### 方法一：使用安装脚本（推荐）
```bash
# 1. 解压插件包
unzip mijia-smart-reminder-v1.0.0-20260320-015518.zip

# 2. 进入插件目录
cd mijia-smart-reminder

# 3. 运行安装脚本
bash scripts/install.sh
```

### 方法二：手动安装
```bash
# 1. 解压插件包
unzip mijia-smart-reminder-v1.0.0-20260320-015518.zip

# 2. 复制到插件目录
cp -r mijia-smart-reminder ~/.workbuddy/plugins/

# 3. 重启 WorkBuddy/Codebuddy
```

## 📋 系统要求

- **操作系统**: macOS 10.15+ 或 Linux
- **工具依赖**: curl, jq
- **WorkBuddy/Codebuddy**: 版本 2.0.0+

## 🔧 首次使用

1. 重启 WorkBuddy/Codebuddy
2. 运行命令: `/mijia-setup`
3. 配置米家账号信息
4. 开始创建提醒

## 📚 更多信息

- 完整文档: README.md
- 更新日志: CHANGELOG.md
- 命令列表: 查看 README.md 中的命令部分

## 🆘 技术支持

如有问题，请查看插件目录下的文档或联系开发者。
